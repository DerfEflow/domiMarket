"""
Media Licensing Generator for Dominate Marketing
Generates licensing agreements for AI-generated content based on subscription tier and usage type
"""
from datetime import datetime, timedelta
from typing import Dict, Optional, List
from dataclasses import dataclass
import uuid
import json

@dataclass
class LicenseTerms:
    license_id: str
    license_type: str
    commercial_use: bool
    distribution_rights: bool
    modification_rights: bool
    attribution_required: bool
    exclusive_rights: bool
    duration_months: Optional[int]
    usage_restrictions: List[str]
    territories: List[str]
    media_types: List[str]

class MediaLicensingGenerator:
    """Generates comprehensive licensing agreements for AI-generated marketing content"""
    
    def __init__(self):
        self.license_templates = {
            'basic': {
                'commercial_use': False,
                'distribution_rights': False,
                'modification_rights': True,
                'attribution_required': True,
                'exclusive_rights': False,
                'duration_months': 12,
                'usage_restrictions': ['Personal use only', 'No resale permitted', 'Non-commercial projects only'],
                'territories': ['Worldwide'],
                'media_types': ['Text content', 'Basic graphics']
            },
            'plus': {
                'commercial_use': True,
                'distribution_rights': True,
                'modification_rights': True,
                'attribution_required': False,
                'exclusive_rights': False,
                'duration_months': 24,
                'usage_restrictions': ['Small business use (under $1M revenue)', 'Up to 50,000 impressions per campaign'],
                'territories': ['Worldwide'],
                'media_types': ['Text content', 'Images', 'Basic videos']
            },
            'pro': {
                'commercial_use': True,
                'distribution_rights': True,
                'modification_rights': True,
                'attribution_required': False,
                'exclusive_rights': True,
                'duration_months': 36,
                'usage_restrictions': ['Enterprise use permitted', 'Unlimited impressions', 'Resale rights included'],
                'territories': ['Worldwide'],
                'media_types': ['All content types', 'High-resolution images', 'Professional videos', 'Audio content']
            },
            'enterprise': {
                'commercial_use': True,
                'distribution_rights': True,
                'modification_rights': True,
                'attribution_required': False,
                'exclusive_rights': True,
                'duration_months': None,  # Lifetime
                'usage_restrictions': ['Unlimited commercial use', 'White-label rights', 'API access included'],
                'territories': ['Worldwide'],
                'media_types': ['All content types', 'Source files included', 'Custom branding rights']
            }
        }
    
    def generate_license(self, 
                        user_tier: str, 
                        content_type: str, 
                        campaign_id: str,
                        user_id: str,
                        custom_terms: Optional[Dict] = None) -> Dict:
        """Generate a comprehensive license agreement"""
        
        license_id = f"DM-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8].upper()}"
        
        # Get base terms for user tier
        base_terms = self.license_templates.get(user_tier.lower(), self.license_templates['basic'])
        
        # Apply custom terms if provided
        if custom_terms:
            base_terms.update(custom_terms)
        
        # Create license terms object
        terms = LicenseTerms(
            license_id=license_id,
            license_type=self._get_license_type_name(user_tier),
            commercial_use=base_terms['commercial_use'],
            distribution_rights=base_terms['distribution_rights'],
            modification_rights=base_terms['modification_rights'],
            attribution_required=base_terms['attribution_required'],
            exclusive_rights=base_terms['exclusive_rights'],
            duration_months=base_terms['duration_months'],
            usage_restrictions=base_terms['usage_restrictions'],
            territories=base_terms['territories'],
            media_types=base_terms['media_types']
        )
        
        # Generate the complete license document
        license_document = self._generate_license_document(terms, content_type, campaign_id, user_id)
        
        return {
            'license_id': license_id,
            'terms': terms.__dict__,
            'document': license_document,
            'generated_at': datetime.now().isoformat(),
            'expires_at': self._calculate_expiry_date(terms.duration_months),
            'download_url': f'/api/license/download/{license_id}',
            'verification_url': f'/api/license/verify/{license_id}'
        }
    
    def _get_license_type_name(self, tier: str) -> str:
        """Get human-readable license type name"""
        tier_names = {
            'basic': 'Personal Use License',
            'plus': 'Small Business License',
            'pro': 'Professional Commercial License',
            'enterprise': 'Enterprise Unlimited License'
        }
        return tier_names.get(tier.lower(), 'Standard License')
    
    def _calculate_expiry_date(self, duration_months: Optional[int]) -> Optional[str]:
        """Calculate license expiry date"""
        if duration_months is None:
            return None  # Lifetime license
        
        expiry_date = datetime.now() + timedelta(days=duration_months * 30)
        return expiry_date.isoformat()
    
    def _generate_license_document(self, terms: LicenseTerms, content_type: str, campaign_id: str, user_id: str) -> str:
        """Generate the full license document text"""
        
        current_date = datetime.now().strftime('%B %d, %Y')
        expiry_text = "This license does not expire" if terms.duration_months is None else f"This license expires {terms.duration_months} months from the issue date"
        
        document = f"""
DOMINATE MARKETING CONTENT LICENSE AGREEMENT

License ID: {terms.license_id}
License Type: {terms.license_type}
Issue Date: {current_date}
Content Type: {content_type}
Campaign ID: {campaign_id}
Licensed User: {user_id}

TERMS AND CONDITIONS

1. GRANT OF LICENSE
Dominate Marketing hereby grants you a {"non-exclusive" if not terms.exclusive_rights else "exclusive"} license to use the AI-generated content described above, subject to the terms and conditions set forth below.

2. PERMITTED USES
Commercial Use: {"PERMITTED" if terms.commercial_use else "NOT PERMITTED"}
Distribution Rights: {"PERMITTED" if terms.distribution_rights else "NOT PERMITTED"}
Modification Rights: {"PERMITTED" if terms.modification_rights else "NOT PERMITTED"}
Attribution Required: {"YES" if terms.attribution_required else "NO"}

3. USAGE RESTRICTIONS
{chr(10).join(f"• {restriction}" for restriction in terms.usage_restrictions)}

4. MEDIA TYPES COVERED
{chr(10).join(f"• {media_type}" for media_type in terms.media_types)}

5. TERRITORY
This license is valid for use in: {", ".join(terms.territories)}

6. DURATION
{expiry_text}

7. ATTRIBUTION REQUIREMENTS
{"When using this content, you must include: 'Content generated by Dominate Marketing AI'" if terms.attribution_required else "No attribution required for this license type"}

8. RESTRICTIONS
• You may not sub-license this content to third parties unless explicitly permitted
• You may not use this content for illegal or harmful purposes
• You may not claim ownership of the underlying AI technology
• Compliance with all applicable laws and regulations is required

9. WARRANTY DISCLAIMER
THIS CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. DOMINATE MARKETING DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

10. LIMITATION OF LIABILITY
IN NO EVENT SHALL DOMINATE MARKETING BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING FROM THE USE OF THIS CONTENT.

11. VERIFICATION
This license can be verified at: /api/license/verify/{terms.license_id}

By using the licensed content, you acknowledge that you have read, understood, and agree to be bound by the terms of this license agreement.

---
© 2025 Dominate Marketing. All rights reserved.
Generated automatically on {current_date}
        """.strip()
        
        return document
    
    def generate_quick_license_summary(self, user_tier: str) -> Dict:
        """Generate a quick summary of licensing terms for a tier"""
        base_terms = self.license_templates.get(user_tier.lower(), self.license_templates['basic'])
        
        return {
            'tier': user_tier,
            'license_type': self._get_license_type_name(user_tier),
            'commercial_use': base_terms['commercial_use'],
            'duration_months': base_terms['duration_months'],
            'key_features': [
                f"{'✓' if base_terms['commercial_use'] else '✗'} Commercial use",
                f"{'✓' if base_terms['distribution_rights'] else '✗'} Distribution rights",
                f"{'✓' if base_terms['modification_rights'] else '✗'} Modification rights",
                f"{'✓' if base_terms['exclusive_rights'] else '✗'} Exclusive rights",
                f"Duration: {base_terms['duration_months']} months" if base_terms['duration_months'] else "Duration: Lifetime"
            ],
            'media_types': base_terms['media_types']
        }
    
    def validate_license(self, license_id: str) -> Dict:
        """Validate a license ID and return status"""
        # In a real implementation, this would check against a database
        # For now, we'll validate format and return mock validation
        
        if not license_id.startswith('DM-'):
            return {'valid': False, 'error': 'Invalid license format'}
        
        return {
            'valid': True,
            'license_id': license_id,
            'status': 'active',
            'verified_at': datetime.now().isoformat()
        }

# Example usage and testing
if __name__ == "__main__":
    generator = MediaLicensingGenerator()
    
    # Test license generation
    license_data = generator.generate_license(
        user_tier='pro',
        content_type='Marketing Video',
        campaign_id='CAMP-12345',
        user_id='user-67890'
    )
    
    print(f"Generated License ID: {license_data['license_id']}")
    print(f"License Type: {license_data['terms']['license_type']}")
    print(f"Commercial Use: {license_data['terms']['commercial_use']}")