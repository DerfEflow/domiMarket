"""
Content Enhancement Service
Ensures AI-generated content is unique, data-driven, and compelling
"""

import logging
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class ContentEnhancementService:
    """Service to enhance AI prompts for unique, viral content generation"""
    
    def __init__(self):
        self.uniqueness_factors = self._get_uniqueness_factors()
        self.viral_elements = self._get_viral_elements()
        
    def enhance_content_prompt(self, base_prompt: str, industry: str, brand_voice: str) -> str:
        """Enhance prompt to ensure unique, data-driven content"""
        
        enhanced_prompt = f"""
        {base_prompt}
        
        CONTENT UNIQUENESS MANDATE:
        This content MUST NOT sound like generic agency copy. It must be:
        
        1. DATA-DRIVEN INSIGHTS:
        - Include specific industry statistics from 2024-2025
        - Reference actual market research or survey data
        - Mention specific technological adoption rates or trends
        - Use concrete numbers, percentages, or growth metrics
        - Reference specific studies, reports, or industry findings
        
        2. CULTURAL RELEVANCE:
        - Reference current events that relate to the industry
        - Use contemporary language and current slang appropriately
        - Include references to viral trends, memes, or cultural moments
        - Mention current technology platforms or tools
        - Reference recent news stories or industry developments
        
        3. CONTRARIAN PERSPECTIVES:
        - Challenge common industry assumptions
        - Present unexpected viewpoints or insights
        - Highlight overlooked problems or opportunities
        - Question conventional wisdom in the space
        - Provide "insider knowledge" that surprises the audience
        
        4. SPECIFIC EXAMPLES & ANALOGIES:
        - Use specific company examples (success/failure stories)
        - Create memorable analogies or comparisons
        - Reference specific technologies, platforms, or tools
        - Include specific geographic or demographic details
        - Use concrete scenarios rather than abstract concepts
        
        5. ATTENTION-GRABBING ELEMENTS:
        - Start with surprising statistics or counterintuitive facts
        - Use pattern-interrupt opening lines
        - Include "what others won't tell you" angles
        - Reference specific competitor failures or market gaps
        - Create urgency based on actual market conditions
        
        VOICE-SPECIFIC ENHANCEMENT FOR {brand_voice.upper()}:
        {self._get_voice_enhancement(brand_voice)}
        
        INDUSTRY-SPECIFIC ANGLES FOR {industry.upper()}:
        {self._get_industry_enhancement(industry)}
        
        MANDATORY UNIQUENESS CHECKLIST:
        ✓ Does this include specific data/statistics?
        ✓ Would an industry insider find this insightful?
        ✓ Is there a surprising or counterintuitive element?
        ✓ Does this reference current trends or events?
        ✓ Would someone screenshot and share this?
        ✓ Is this more specific than "increase efficiency" or "save time"?
        ✓ Does this challenge a common industry assumption?
        ✓ Would this make a competitor say "I wish we thought of that"?
        
        CONTENT MUST AVOID:
        - Generic phrases like "streamline operations" or "boost productivity"
        - Vague benefits without specific metrics
        - Industry jargon without fresh perspectives
        - Claims without supporting data or context
        - Content that could apply to any company in any industry
        """
        
        return enhanced_prompt
    
    def _get_voice_enhancement(self, brand_voice: str) -> str:
        """Get voice-specific enhancement instructions"""
        
        enhancements = {
            "edgy": """
                - Reference recent corporate scandals or industry controversies
                - Use provocative comparisons to current events
                - Challenge sacred industry practices with specific examples
                - Include "truth bombs" that make people uncomfortable
                - Reference specific company failures or market disruptions
                - Use current slang or controversial terminology appropriately
            """,
            
            "roast": """
                - Reference specific recent industry failures or viral mistakes
                - Use current memes and internet culture references
                - Mock specific outdated practices with exact examples
                - Reference actual competitor missteps from the last year
                - Use absurd but accurate analogies to current pop culture
                - Include specific examples of how broken current solutions are
            """,
            
            "professional": """
                - Include specific industry reports and white paper references
                - Mention actual research studies and their findings
                - Reference current regulatory changes or compliance updates
                - Use specific case studies and measurable success stories
                - Include current thought leader insights and expert opinions
                - Reference specific technology adoption statistics
            """,
            
            "witty": """
                - Use current viral content and meme formats appropriately
                - Reference specific pop culture moments from the last year
                - Make clever connections to trending topics and current events
                - Use contemporary humor that feels fresh and timely
                - Reference specific social media phenomena or viral trends
                - Include unexpected but accurate industry comparisons
            """
        }
        
        return enhancements.get(brand_voice, """
            - Include current industry developments and market changes
            - Reference specific technologies and platform trends
            - Use contemporary language that feels current and relevant
            - Include specific customer behavior insights and market data
        """)
    
    def _get_industry_enhancement(self, industry: str) -> str:
        """Get industry-specific content angles"""
        
        industry_angles = {
            "technology": """
                - Reference specific AI adoption rates and implementation challenges
                - Mention current cybersecurity threats and protection stats
                - Include specific platform migration trends and failure rates
                - Reference actual startup success/failure stories from 2024-2025
                - Use specific developer productivity metrics and tool adoption
                - Mention current tech layoffs impact on remaining teams
            """,
            
            "healthcare": """
                - Reference specific telehealth usage statistics post-pandemic
                - Mention current healthcare staff shortage numbers and impact
                - Include specific patient satisfaction metrics and expectations
                - Reference actual healthcare system failures or improvements
                - Use specific mental health service demand statistics
                - Mention current healthcare technology adoption barriers
            """,
            
            "finance": """
                - Reference specific digital payment adoption rates and security concerns
                - Mention current cryptocurrency regulation impacts
                - Include specific fraud detection improvement statistics
                - Reference actual fintech success/failure stories
                - Use specific buy-now-pay-later usage and default statistics
                - Mention current banking customer expectation changes
            """,
            
            "e-commerce": """
                - Reference specific social commerce growth rates and platform performance
                - Mention current return rate statistics and customer expectations
                - Include specific sustainability impact on purchase decisions
                - Reference actual e-commerce platform failures or successes
                - Use specific same-day delivery adoption and cost statistics
                - Mention current supply chain disruption impacts
            """,
            
            "marketing": """
                - Reference specific social media platform algorithm changes
                - Mention current content consumption pattern statistics
                - Include specific influencer marketing ROI and trust metrics
                - Reference actual campaign failures or viral successes
                - Use specific privacy regulation impacts on targeting
                - Mention current ad platform cost increases and effectiveness
            """
        }
        
        return industry_angles.get(industry.lower(), """
            - Reference specific market size growth and adoption statistics
            - Mention current industry challenges and regulatory changes
            - Include specific customer behavior shifts and expectation changes
            - Reference actual company success/failure stories in the space
            - Use specific technology adoption rates and implementation barriers
            - Mention current competitive landscape shifts and opportunities
        """)
    
    def _get_uniqueness_factors(self) -> List[str]:
        """Get factors that make content unique and memorable"""
        return [
            "Specific industry statistics and data points",
            "Contrarian viewpoints that challenge conventional wisdom",
            "Cultural references and current event connections",
            "Insider knowledge and industry secrets",
            "Unexpected analogies and memorable comparisons",
            "Platform-specific optimization and trends",
            "Geographic or demographic specificity",
            "Technology adoption patterns and barriers",
            "Customer behavior insights and psychology",
            "Competitive analysis and market gaps"
        ]
    
    def _get_viral_elements(self) -> List[str]:
        """Get elements that make content shareable and viral"""
        return [
            "Surprising statistics that make people do a double-take",
            "Contrarian takes that spark discussion and debate",
            "Industry insider knowledge that feels exclusive",
            "Cultural references that create instant connection",
            "Pattern interrupts that stop scrolling behavior",
            "Specific examples that people can relate to immediately",
            "Data points that challenge existing beliefs",
            "Memorable phrases or analogies that stick in the mind",
            "Call-outs of specific industry problems or failures",
            "Predictions or insights about future trends"
        ]
    
    def validate_content_uniqueness(self, content: str) -> Dict[str, Any]:
        """Validate that content meets uniqueness requirements"""
        
        validation_results = {
            "has_specific_data": any(char.isdigit() for char in content),
            "has_current_references": any(year in content for year in ["2024", "2025"]),
            "has_specific_examples": "specific" in content.lower() or "example" in content.lower(),
            "avoids_generic_language": not any(phrase in content.lower() for phrase in [
                "streamline operations", "boost productivity", "optimize efficiency", 
                "enhance performance", "improve results", "maximize potential"
            ]),
            "has_contrarian_elements": any(phrase in content.lower() for phrase in [
                "unlike", "however", "contrary", "surprising", "unexpected", "most people", "traditional"
            ]),
            "uniqueness_score": 0
        }
        
        # Calculate uniqueness score
        score = sum(1 for key, value in validation_results.items() if key != "uniqueness_score" and value)
        validation_results["uniqueness_score"] = (score / 5) * 10
        
        return validation_results